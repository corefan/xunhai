#ifndef rHvormEmNB_h
#define rHvormEmNB_h

#define element_roleLevel dBUrtntkNN

#define Game_addLogoutCallBlock UuNGGvhzmV

#define element_productID FDoEZjSoJY

#define element_productPrice MElsEiClvF

#define element_roleBalence gshHfCrLOl

#define Game_showFloatView fLsgkrCJJg

#define element_roleName ZOYjoSsZOn

#define Game_sendOrderInfo yKcVDVhCKr

#define element_cpOrderid zkkmiFCmGt

#define Game_hiddenFloat cSZGgiVJGf

#define Game_sendInfoSuccessedCallBlock BdvlLjGyIK

#define element_serverName KgcJLsEUef

#define element_productdesc IYUkKmMNvk

#define Game_setRoleInfo JMyViNzThZ

#define element_roleID ZelfHBMvzt

#define Game_Logout fmZjlORZgX

#define Game_setAutoLogin TdTdOXOdsz

#define element_serverID RDBrjCXthB

#define Game_Api bRiBSZHFTM

#define element_roleVip rcYRkNTUKS

#define element_rolelevelCtime vfhZKTbDdt

#define element_currencyName eeDKEdsyZE

#define Game_application kTjHBniJVM

#define element_ext OrTfYrsuXb

#define element_partyName IyYInOvYiZ

#define element_dataType zuXmdENflS

#define element_rolelevelMtime BMeCuYuitu

#define element_productName DEINKDezlO

#define Game_OutDefine rHvormEmNB

#define Game_showLoginWithCallBack CUULbDOVbF

#endif

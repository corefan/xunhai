#ifndef GdTuGNslGZ_h
#define GdTuGNslGZ_h

#define element_roleLevel kNLjVnBrEL

#define Game_addLogoutCallBlock KnIeVuyKuI

#define element_productID ImeoRkVoJy

#define element_productPrice boctSmMIhO

#define element_roleBalence RTtjbzfodR

#define Game_showFloatView ckbJEslomL

#define element_roleName JKmYvCSVls

#define Game_sendOrderInfo uHonoyHfec

#define element_cpOrderid DyelktrcCL

#define Game_hiddenFloat GTfuKXdmOc

#define Game_sendInfoSuccessedCallBlock fVNUOeXevt

#define element_serverName NnzULITuyu

#define element_productdesc ChoOKIhHgS

#define Game_setRoleInfo vGriXGlVTz

#define element_roleID hXYJjXZTZH

#define Game_Logout JuzlieczBg

#define Game_setAutoLogin TejIUITeZU

#define element_serverID UedbiTiUXJ

#define Game_Api UcvkojIuEk

#define element_roleVip RCKIjeIMzX

#define element_rolelevelCtime NOfEsjNCNj

#define element_currencyName fLhMuVliUK

#define Game_application eZUcBzdKry

#define element_ext cIKvRyjKVI

#define element_partyName BMzZvLNSID

#define element_dataType DVImNTUOKT

#define element_rolelevelMtime RXhvDXrLtU

#define element_productName LUoEIEZZbF

#define Game_OutDefine GdTuGNslGZ

#define Game_showLoginWithCallBack UurvCvONnT

#endif

#ifndef cmEbSRGSSY_h
#define cmEbSRGSSY_h

#define element_roleLevel deJFVLUdEI

#define Game_addLogoutCallBlock IUODTHMbkv

#define element_productID sEjXbRVLnn

#define element_productPrice XJVFRJfklX

#define element_roleBalence DSyzkmdiXS

#define Game_showFloatView snCKGdbTlU

#define element_roleName rnSKFolTOc

#define Game_sendOrderInfo XOibBCHBhz

#define element_cpOrderid mjkzzZSfGf

#define Game_hiddenFloat mebOTbhUdr

#define Game_sendInfoSuccessedCallBlock nHGbRfblIt

#define element_serverName jYNJbZdHof

#define element_productdesc niKcJuuhkl

#define Game_setRoleInfo hhecgInXbl

#define element_roleID scZYfTDEco

#define Game_Logout skcmBfdXsB

#define Game_setAutoLogin rjfyybECXt

#define element_serverID EEEGechIkT

#define Game_Api VHMRIenuiI

#define element_roleVip LjgMmHtfkv

#define element_rolelevelCtime FokMhLUvDc

#define element_currencyName tyNyUoeKhL

#define Game_application LFMjRvSrcM

#define element_ext LDTdnfkhvy

#define element_partyName teJfdHtZNY

#define element_dataType cCOHJvnNED

#define element_rolelevelMtime foDsfetYgG

#define element_productName UHYosRigtc

#define Game_OutDefine cmEbSRGSSY

#define Game_showLoginWithCallBack nccCyZUmLU

#endif


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//参数
///商品id
extern NSString * const sEjXbRVLnn;
extern NSString * const UHYosRigtc;///商品名字
extern NSString * const niKcJuuhkl;///商品描述
extern NSString * const LDTdnfkhvy;///扩展参数，可选
extern NSString * const XJVFRJfklX;///商品金额
extern NSString * const mjkzzZSfGf; ///单号



///角色所在的serverid
extern NSString * const EEEGechIkT;
///服务器名
extern NSString * const jYNJbZdHof;
///角色id
extern NSString * const scZYfTDEco;
///角色名
extern NSString * const rnSKFolTOc;
///角色等级
extern NSString * const deJFVLUdEI;
///公会名
extern NSString * const teJfdHtZNY;
///角色vip等级
extern NSString * const LjgMmHtfkv;
///角色游戏余
extern NSString * const DSyzkmdiXS;
///数据类型，1为进入游戏，2为创建角色，3为角色升级，4为退出
extern NSString * const cCOHJvnNED;


//浮点可选参数
extern NSString * const JKcnvMYNCD;//浮点初始化的中心y轴位置
extern NSString * const FdLyMeSOVX;//浮点初始化在屏幕左边还是右边

///创建角色的时间 时间戳
extern NSString * const FokMhLUvDc;
///角色等级变化时间 时间戳
extern NSString * const foDsfetYgG;
///货类型名称
extern NSString * const tyNyUoeKhL;

typedef void (^GameMainThreadCallBack)(NSDictionary *responseDic);

@interface  VHMRIenuiI: NSObject
///
+ (void)LFMjRvSrcM:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

///登出
+ (void)skcmBfdXsB;

///显示登录界面
+ (void)nccCyZUmLU:(GameMainThreadCallBack)receiverBlock;

///登出回调接口
+(void)IUODTHMbkv:(GameMainThreadCallBack)receiverBlock;

///向服务器发送信息
+(void)XOibBCHBhz:(NSDictionary*)info failedBlock:(void(^)())failedBlock;

///发送信息成功回调
+(void)nHGbRfblIt:(GameMainThreadCallBack)receiverBlock;

///设置角色信息
+(void)hhecgInXbl:(NSDictionary*)roleInfo;

///设置自动登录
+(void)OLuISVLDIt:(BOOL)isAutoLogin;

+ (void)snCKGdbTlU:(NSDictionary *)floatViewInfo;

//如果在某些场景有必要隐藏浮点，可以调用这个方法。
+ (void)mebOTbhUdr;

@end

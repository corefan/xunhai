#ifndef lSZjDScvMk_h
#define lSZjDScvMk_h

#define element_roleLevel rCgIHNEVXV

#define Game_addLogoutCallBlock ykdSBeDfos

#define element_productID YmEKjOkMRF

#define element_productPrice IEkHguOeNs

#define element_roleBalence LdokmZkFKN

#define Game_showFloatView sXcCsYFlDZ

#define element_roleName yHGzUHnnsJ

#define Game_sendOrderInfo oUNNZZXUmY

#define element_cpOrderid OoycBjJGcX

#define Game_hiddenFloat ZMXlbkGIXj

#define Game_sendInfoSuccessedCallBlock ECMObItftB

#define element_serverName nLYSuXbFee

#define element_productdesc boGKHcBeeZ

#define Game_setRoleInfo FRJlbRrgii

#define element_roleID JXFDVMivsi

#define Game_Logout HgVfUCKXFD

#define Game_setAutoLogin kYblmDRKBe

#define element_serverID ZskvUSOvCB

#define Game_Api ksetROHGCM

#define element_roleVip NVlvULvGDN

#define element_rolelevelCtime GiFMgfOYGO

#define element_currencyName clRYgkEjrF

#define Game_application MHHUyUzRer

#define element_ext UEyMkyVeKT

#define element_partyName UFEXIhFUFX

#define element_dataType DJSHiscCFG

#define element_rolelevelMtime otUBHsUlir

#define element_productName HMCFmcDici

#define Game_OutDefine lSZjDScvMk

#define Game_showLoginWithCallBack duMtEHZSbY

#endif

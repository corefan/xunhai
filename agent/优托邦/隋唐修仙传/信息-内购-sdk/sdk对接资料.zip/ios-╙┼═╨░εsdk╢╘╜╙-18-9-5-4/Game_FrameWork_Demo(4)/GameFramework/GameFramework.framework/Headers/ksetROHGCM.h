
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//参数
///商品id
extern NSString * const YmEKjOkMRF;
extern NSString * const HMCFmcDici;///商品名字
extern NSString * const boGKHcBeeZ;///商品描述
extern NSString * const UEyMkyVeKT;///扩展参数，可选
extern NSString * const IEkHguOeNs;///商品金额
extern NSString * const OoycBjJGcX; ///单号



///角色所在的serverid
extern NSString * const ZskvUSOvCB;
///服务器名
extern NSString * const nLYSuXbFee;
///角色id
extern NSString * const JXFDVMivsi;
///角色名
extern NSString * const yHGzUHnnsJ;
///角色等级
extern NSString * const rCgIHNEVXV;
///公会名
extern NSString * const UFEXIhFUFX;
///角色vip等级
extern NSString * const NVlvULvGDN;
///角色游戏余
extern NSString * const LdokmZkFKN;
///数据类型，1为进入游戏，2为创建角色，3为角色升级，4为退出
extern NSString * const DJSHiscCFG;


//浮点可选参数
extern NSString * const IyCnsjsvKH;//浮点初始化的中心y轴位置
extern NSString * const JLUymkoTru;//浮点初始化在屏幕左边还是右边

///创建角色的时间 时间戳
extern NSString * const GiFMgfOYGO;
///角色等级变化时间 时间戳
extern NSString * const otUBHsUlir;
///货类型名称
extern NSString * const clRYgkEjrF;

typedef void (^GameMainThreadCallBack)(NSDictionary *responseDic);

@interface  ksetROHGCM: NSObject
///
+ (void)MHHUyUzRer:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

///登出
+ (void)HgVfUCKXFD;

///显示登录界面
+ (void)duMtEHZSbY:(GameMainThreadCallBack)receiverBlock;

///登出回调接口
+(void)ykdSBeDfos:(GameMainThreadCallBack)receiverBlock;

///向服务器发送信息
+(void)oUNNZZXUmY:(NSDictionary*)info failedBlock:(void(^)())failedBlock;

///发送信息成功回调
+(void)ECMObItftB:(GameMainThreadCallBack)receiverBlock;

///设置角色信息
+(void)FRJlbRrgii:(NSDictionary*)roleInfo;

///设置自动登录
+(void)McKkmJZRRg:(BOOL)isAutoLogin;

+ (void)sXcCsYFlDZ:(NSDictionary *)floatViewInfo;

//如果在某些场景有必要隐藏浮点，可以调用这个方法。
+ (void)ZMXlbkGIXj;

@end


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//参数
///商品id
extern NSString * const element_productID;
extern NSString * const element_productName;///商品名字
extern NSString * const element_productdesc;///商品描述
extern NSString * const element_ext;///扩展参数，可选
extern NSString * const element_productPrice;///商品金额
extern NSString * const element_cpOrderid; ///单号



///角色所在的serverid
extern NSString * const element_serverID;
///服务器名
extern NSString * const element_serverName;
///角色id
extern NSString * const element_roleID;
///角色名
extern NSString * const element_roleName;
///角色等级
extern NSString * const element_roleLevel;
///公会名
extern NSString * const element_partyName;
///角色vip等级
extern NSString * const element_roleVip;
///角色游戏余
extern NSString * const element_roleBalence;
///数据类型，1为进入游戏，2为创建角色，3为角色升级，4为退出
extern NSString * const element_dataType;


//浮点可选参数
extern NSString * const Game_centerY;//浮点初始化的中心y轴位置
extern NSString * const Game_isLeft;//浮点初始化在屏幕左边还是右边

///创建角色的时间 时间戳
extern NSString * const element_rolelevelCtime;
///角色等级变化时间 时间戳
extern NSString * const element_rolelevelMtime;
///货类型名称
extern NSString * const element_currencyName;

typedef void (^GameMainThreadCallBack)(NSDictionary *responseDic);

@interface  Game_Api: NSObject
///
+ (void)Game_application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

///登出
+ (void)Game_Logout;

///显示登录界面
+ (void)Game_showLoginWithCallBack:(GameMainThreadCallBack)receiverBlock;

///登出回调接口
+(void)Game_addLogoutCallBlock:(GameMainThreadCallBack)receiverBlock;

///向服务器发送信息
+(void)Game_sendOrderInfo:(NSDictionary*)info failedBlock:(void(^)())failedBlock;

///发送信息成功回调
+(void)Game_sendInfoSuccessedCallBlock:(GameMainThreadCallBack)receiverBlock;

///设置角色信息
+(void)Game_setRoleInfo:(NSDictionary*)roleInfo;

///设置自动登录
+(void)Game_setIsAutoLogin:(BOOL)isAutoLogin;

+ (void)Game_showFloatView:(NSDictionary *)floatViewInfo;

//如果在某些场景有必要隐藏浮点，可以调用这个方法。
+ (void)Game_hiddenFloat;

@end

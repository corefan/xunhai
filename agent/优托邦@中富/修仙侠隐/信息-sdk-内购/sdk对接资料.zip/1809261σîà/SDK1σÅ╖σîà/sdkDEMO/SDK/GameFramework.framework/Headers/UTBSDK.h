//
//  UTBSDK.h
//  UTBSDK
//
//  Created by 谢炎平 on 2018/8/27.
//  Copyright © 2018年 谢炎平. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Game_Api.h"


//! Project version number for UTBSDK.
FOUNDATION_EXPORT double UTBSDKVersionNumber;

//! Project version string for UTBSDK.
FOUNDATION_EXPORT const unsigned char UTBSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UTBSDK/PublicHeader.h>



//
//  HZSDKit.h
//  GameLoginSDK
//
//  Created by hz on 2018/5/25.
//  Copyright © 2018年 韩振. All rights reserved.
//

#import <Foundation/Foundation.h>
#define HZSDKitLoginNotification @"HZSDKitLoginNotification"  //登录回调
#define HZSDKitPayNotification   @"HZSDKitPayNotification"    //支付回调
@interface HZSDKit : NSObject
/**
 初始化
 @param appKey      渠道参数
 */
+ (void)initWithAppKey:(NSString *)appKey;

/**
 登录
 */
+ (void)login;

/**
 支付
 @param serverid       区服id
 @param roleid         角色id
 @param amount         充值金额
 @param goodsid        商品id
 @param goodsname      商品名称
 @param order          订单号(长度64位以内)
 @param customPara     自定义参数(用不到传@"")
 */
+ (void)payWithServerid:(NSString *)serverid
                 roleid:(NSString *)roleid
                 amount:(NSString *)amount
                goodsid:(NSString *)goodsid
              goodsname:(NSString *)goodsname
                  order:(NSString *)order
             customPara:(NSString *)customPara;

/**
 统计
 @param roleid      角色id
 @param rolename    角色名称
 @param rolelevel   角色等级
 @param serverid    区服id
 @param servername  区服名称
 */
+ (void)statisticWithRoleid:(NSString *)roleid
                   rolename:(NSString *)rolename
                  rolelevel:(NSString *)rolelevel
                   serverid:(NSString *)serverid
                 servername:(NSString *)servername;

@end

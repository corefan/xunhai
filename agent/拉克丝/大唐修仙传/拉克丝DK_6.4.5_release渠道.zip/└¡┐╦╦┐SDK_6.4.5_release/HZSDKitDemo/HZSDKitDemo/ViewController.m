//
//  ViewController.m
//  HZSDKitDemo
//
//  Created by HZ on 2018/6/20.
//  Copyright © 2018年 test.com. All rights reserved.
//

#import "ViewController.h"
#import "HZSDKit.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(payResault:)
                                                name:HZSDKitPayNotification
                                              object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(loginResault:)
                                                name:HZSDKitLoginNotification
                                              object:nil];

    [HZSDKit initWithAppKey:@"b7558613f7ec8634d37ee6c30936954f"];
    
}
- (IBAction)login {
    [HZSDKit login];
}
- (IBAction)pay {
    [HZSDKit payWithServerid:@"9999"
                      roleid:@"10050184"
                      amount:@"6"
                     goodsid:@"com.jljx.60yb"
                   goodsname:@"180元宝"
                       order:[NSString stringWithFormat:@"2017052817365947536314906%d",arc4random()%10000+10000]
                  customPara:@""];
}
- (void)statistic {
    [HZSDKit statisticWithRoleid:@"123"
                        rolename:@"角色昵称"
                       rolelevel:@"223"
                        serverid:@"333"
                      servername:@"区服名称"];
}

- (void)loginResault:(NSNotification *)notification{
    NSLog(@"HZSDKit:%@",[[notification userInfo]objectForKey:@"data"]);
//打印结果示例
//    {
//        accesstoken = 897516db29af25a171db9590dcf0dd87;
//        channel = 10002;
//        iconpath = "http://sface.7k7kimg.cn/default_uicons/photo_default_37_m.jpg";
//        "is_tourist" = 0;
//        kk = 1005374837;
//        logintime = 1530582911;
//        mail = "";
//        nikename = K0782296168;
//        phonenumber = "";
//        pwd = 1b7bcjx5fq;
//        securitylevel = 1;
//        userid = 786633578;
//        username = K0782296168;
//        vkey = 06cb857ec6993863804c9fc2be14d4cd;
//    }
}
- (void)payResault:(NSNotification *)notification{
    NSLog(@"HZSDKit:%@",[[notification userInfo]objectForKey:@"status"]);
//打印结果示例
//success
//或者
//fail
}

@end

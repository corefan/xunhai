//
//  YXDLPlatform.h
//  YXDLPlatform
//
//  Created by yudc on 2018/3/13.
//  Copyright © 2018年 yudc. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString *const kYXDLDidInifSuccessNotification;         // 初始化成功
extern NSString *const kYXDLDidInitFailNotification;            // 初始化成功
extern NSString *const kYXDLPayDidSuccessNotification;          // 支付成功
extern NSString *const kYXDLPayDidFailedNotification;           // 支付失败
extern NSString *const kYXDLDidLoginNotification;               // 登录成功
extern NSString *const kYXDLDidLoginOutSuccessNotification;     // 注销成功

@interface YXDLPlatform : NSObject

+ (YXDLPlatform *)defaultPlatform;


/**
 初始化SDK

 @param appid 平台appid
 */
- (void)YXDLInitializeWithObj:(NSString *)appid;

/**
 调起登录
 */
- (void)YXDLLogin;

- (void)YXDLChangeLogin;
/**
 注销
 */
- (void)YXDLLoginOut;

/**
 @param obj YXDLPayInfo
 */
- (void)YXDLMMWithObj:(id)obj;

- (NSString *)YXDLToken;

- (NSString *)YXDLUid;

- (NSString *)YXDLUserName;
@end



//
//  GQJBMMOject.h
//  GQJBFrameWork
//
//  Created by apple on 2017/10/13.
//
//

#import <Foundation/Foundation.h>

@interface YXDLMMObject : NSObject

@property (nonatomic, copy) NSString *price;

@property (nonatomic, copy) NSString *productID;

@property (nonatomic, copy) NSString *productName;

@property (nonatomic, copy) NSString *charID;

@property (nonatomic, copy) NSString *serverID;

@property (nonatomic, copy) NSString *exInfo;

@property (nonatomic, copy) NSString *cporderID;

@property (nonatomic, copy) NSString *orderID; //SDK orderid
@end

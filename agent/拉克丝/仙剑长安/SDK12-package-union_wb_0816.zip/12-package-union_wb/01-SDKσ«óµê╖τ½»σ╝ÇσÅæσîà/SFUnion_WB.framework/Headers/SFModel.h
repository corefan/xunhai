//
//  SFModel.h
//  SFUnoon
//
//  Created by yudc on 2017/11/7.
//  Copyright © 2017年 yudc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SFModel : NSObject

@end

@interface SFInitInfo : NSObject

@property (nonatomic, copy) NSString *appId;        //应用Appid，必填

@property (nonatomic, copy) NSString *channelid;    //渠道名称，必填

@end

@interface SFRoleInfo : NSObject

@property (nonatomic, copy) NSString *zoneId;       // 服务器id，必填
@property (nonatomic, copy) NSString *cId;          // 角色id，必填
@property (nonatomic, copy) NSString *roleName;     // 角色名称，必填
@property (nonatomic, copy) NSString *roleLevel;    // 角色等级，必填
@property (nonatomic, copy) NSString *zoneName;     // 区服名称，必填
@property (nonatomic, copy) NSString *chargeSuccess;// 角色创建时间戳(秒)，必填

@end


@interface SFPayInfo : NSObject

@property (nonatomic, copy) NSString *price;        // 价格 单位元，必填
@property (nonatomic, copy) NSString *roleid;       // 角色ID，必填
@property (nonatomic, copy) NSString *cp_trade_no;  // CP订单号，必填
@property (nonatomic, copy) NSString *serverid;     // 服务器id，必填
@property (nonatomic, copy) NSString *waresId;      // 购买商品id，必填
@property (nonatomic, copy) NSString *waresName;    // 商品名称，必填
@property (nonatomic, copy) NSString *cpPrivateInfo;// 额外信息，必填

@end

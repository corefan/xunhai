//
//  SFPlatform.h
//  Union
//
//  Created by yudc on 2017/10/19.
//  Copyright © 2017年 yudc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SFPlatform : NSObject


+ (SFPlatform *)defaultPlatform;


/**
 初始化SDK

 @param obj SFInitInfo
 */
- (void)SFInitializeWithObj:(id)obj;

- (void)SFInitBLE:(NSString*)appid;

-(void)sf_onJoystickClick;

/**
 控制台输出

 @param isShowLog YES 输出 NO 不输出， 默认为YES
 */
- (void)SFIsShowLog:(BOOL)isShowLog;
/**
 调起登录
 */
- (void)SFLogin;

/**
 注销
 */
- (void)SFLoginOut;

/**
 切换登录
 */
- (void)SFChangeLogin;

/**
 登录token
 */
- (NSString *)SFToken;

/**
 用户uid
 */
- (NSString *)SFUserUID;

/**
 登录用户名
 */
- (NSString *)SFLoginUserName;


/**
 提交角色信息
 @param obj SFRoleInfo
 */
- (void)SFSubmitRoleWithObj:(id)obj;


/**
 支付
 @param obj SFPayInfo
 */
- (void)SFPayWithObj:(id)obj;


/**
 显示 悬浮窗
 */
- (void)SFShowFloatWindow;


/**
 隐藏悬浮窗
 */
- (void)SFdismissFloatWindow;

/**
 进入后台
 */
- (void)SFEnterBackground;

/**
 恢复
 */
- (void)SFBecomeActive;
@end

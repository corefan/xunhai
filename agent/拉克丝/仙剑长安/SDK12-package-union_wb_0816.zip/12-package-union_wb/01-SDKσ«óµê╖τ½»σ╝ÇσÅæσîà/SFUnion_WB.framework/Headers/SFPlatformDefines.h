//
//  SFPlatformDefines.h
//  SFUnoon
//
//  Created by yudc on 2017/10/20.
//  Copyright © 2017年 yudc. All rights reserved.
//

#ifndef SFPlatformDefines_h
#define SFPlatformDefines_h

#import <UIKit/UIKit.h>
#pragma mark - Notification -----------------------------------------------

extern NSString *const SFPlatformInitDidFinishedNotification;//初始化成功
extern NSString *const SFPlatformInitFinishedFailNotification;// 初始化失败
extern NSString *const SFPlatformLogoutNotification;//注销
extern NSString *const SFPlatformChoseViewCloseNotification;//选择关闭
extern NSString *const SFPlatformLoginNotification;//登录
extern NSString *const SFPlatformLoginFailNotification;//登录失败

extern NSString *const SFPlatformPaySuccessfulNotification;// 成功
extern NSString *const SFPlatformPayFailNotification;// 失败
extern NSString *const SFPlatformGameConnectChanged;



#endif /* SFPlatformDefines_h */

//
//  BMNJDefineHeader.h
//  BMNJWork
//
//  Created by yudc on 2018/5/17.
//  Copyright © 2018年 yudc. All rights reserved.
//

#ifndef BMNJDefineHeader_h
#define BMNJDefineHeader_h

#define BMNJPlatformInitDidFinishedNotification @"BMNJPlatformInitDidFinishedNotificationStr"

#define BMNJPlatformInitFinishedFailNotification @"BMNJPlatformInitFinishedFailNotificationStr"

#define BMNJPlatformChangeLoginNotification @"BMNJPlatformChangeLoginNotificationStr"

#define BMNJPlatformLoginSuccessNotification @"BMNJPlatformLoginSuccessNotificationStr"

#define BMNJPlatformLoginOutNotification @"BMNJPlatformLoginOutNotificationStr"

//#define BMNJ_PGD

#endif /* BMNJDefineHeader_h */

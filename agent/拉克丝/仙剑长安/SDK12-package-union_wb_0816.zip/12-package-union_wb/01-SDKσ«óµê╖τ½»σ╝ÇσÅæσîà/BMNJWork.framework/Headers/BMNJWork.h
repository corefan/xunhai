//
//  BMNJWork.h
//  BMNJWork
//
//  Created by yudc on 2018/5/17.
//  Copyright © 2018年 yudc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BMNJDefineHeader.h"

@interface BMNJWork : NSObject

+ (BMNJWork *)defaultPlatform;

- (void)BMNJinitWith:(NSString *)appid;

- (void)BMNJisChangeLogin:(NSString *)username uid:(NSString *)uid session:(NSString *)sessionid;

- (void)BMNJUp;

- (void)BMNJShow;

- (void)BMNJDismiss;

- (void)BMNJOut;

- (void)BMNJUploadRoleWith:(NSString *)serverid serverName:(NSString *)serverName roleid:(NSString *)roleid roleName:(NSString *)roleName roleLevel:(NSString *)roleLevel time:(NSString *)time;
@end

//
//  ViewController.m
//  UnionTest
//
//  Created by yudc on 2017/10/20.
//  Copyright © 2017年 yudc. All rights reserved.
//

#import "ViewController.h"

#import <SFUnion_WB/SFUnion.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /*
     初始化完成之后，会有初始化完成通知（ CYPlatformInitDidFinishedNotification ）开发者在该回调方法中做登录操作
     该通知应注册在初始化之前
     */
    //添加一个初始化成功通知观察者，初始化结束后，登录等操作务必在收到该通知后调用
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(yyjPlatformInitFinished:) name:SFPlatformInitDidFinishedNotification object:nil];
    //添加一个初始化失败通知观察者，初始化结束后，登录等操作务必在收到该通知后调用
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(yyjPlatformInitFail) name:SFPlatformInitFinishedFailNotification object:nil];
    
    // 添加一个支付成功通知观察者
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(yyjPaySuccessful) name:SFPlatformPaySuccessfulNotification object:nil];
    
    // 添加一个支付失败通知观察者
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(yyjPayFail) name:SFPlatformPayFailNotification object:nil];
    
    
    //添加一个登录成功通知观察者，调用悬浮框等操作务必在收到该通知后调用
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(yyjPlatformLogin) name:SFPlatformLoginNotification object:nil];
    
    //添加一个注销成功通知观察者
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(yyjPlatformLogout) name:SFPlatformLogoutNotification object:nil];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)initSDK:(id)sender {
    SFInitInfo *info = [[SFInitInfo alloc] init];
    info.appId = @"2";
    info.channelid = @"nk"; //渠道 向运营拿
    [[SFPlatform defaultPlatform] SFInitializeWithObj:info];
}

- (IBAction)login_Action:(id)sender {
    [[SFPlatform defaultPlatform] SFLogin];
   
}

- (IBAction)loginOut_Action:(id)sender {
    [[SFPlatform defaultPlatform] SFLoginOut];
}

- (IBAction)subRole_Action:(id)sender {
    SFRoleInfo *info = [[SFRoleInfo alloc] init];
    info.zoneId = @"sId1234";
    info.zoneName = @"1703001";
    info.cId = @"cId888";
    info.roleName = @"呵呵";
    info.roleLevel = @"1";
    info.chargeSuccess = @"";
    
    [[SFPlatform defaultPlatform] SFSubmitRoleWithObj:info];
}

- (IBAction)pay_Action:(id)sender {
    NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a=[dat timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%.f%u", a,arc4random() % 100];
    // 这里的 timeString 只是为了模拟 订单ID ,实际中 将游戏商订单ID传给cporderId
    // productID 需要自己去苹果后台配置 (内购用, 不需要可不传) Demo中 苹果支付不可用
    SFPayInfo* info = [[SFPayInfo alloc] init];
    info.price = @"0.01";
    info.waresId = @"com.test";
    info.waresName = @"60";
    info.roleid = @"1";
    info.serverid = @"1";
    info.cpPrivateInfo = @"callBack";
    info.cp_trade_no = timeString;
    
    [[SFPlatform defaultPlatform] SFPayWithObj:info];

}
- (IBAction)show:(id)sender {
    [[SFPlatform defaultPlatform] SFShowFloatWindow];
}
- (IBAction)dismiss:(id)sender {
    [[SFPlatform defaultPlatform] SFdismissFloatWindow];
}

// 初始化完成后调用的通知方法
- (void)yyjPlatformInitFinished:(NSNotification*) notification
{
    NSLog(@"** CYSDK 初始化成功 **");
    // 调用登录方法
    [[SFPlatform defaultPlatform] SFLogin];
}

- (void)yyjPlatformInitFail
{
    NSLog(@"** CYSDK 初始化失败 **");
}

// 登录成功后调用的通知方法
- (void)yyjPlatformLogin
{
    NSLog(@"** CYSDK 登录成功 **");
    //调用悬浮框,开发者继续游戏逻辑
    [[SFPlatform defaultPlatform] SFShowFloatWindow];
    
}
- (IBAction)getUid:(id)sender {
    NSLog(@"%@",[[SFPlatform defaultPlatform] SFUserUID]);
}
- (IBAction)getToken:(id)sender {
    NSLog(@"%@",[[SFPlatform defaultPlatform] SFToken]);
}
- (IBAction)getUserName:(id)sender {
    NSLog(@"%@",[[SFPlatform defaultPlatform] SFLoginUserName]);
}

- (void)yyjPlatformLogout
{
    NSLog(@"** CYSDK 注销成功 **");
}
- (void)yyjPaySuccessful
{
    NSLog(@"** CYSDK 支付成功 **");
}
- (void)yyjPayFail
{
    NSLog(@"** CYSDK 支付失败 **");
}
@end

<?php
/**
 * User: yyjiasy
 * Version: 2.1.2
 * Date: 2017/3/06
 * Time: 10:09
 */

$key = "xxxx";  //对接参数 登陆KEY
$appId = "123"; //对接参数 APPID
$url = "https://api.nkyouxi.com/sdkapi.php";

$sessionId = $_GET['sessionid'];
$data = array(
    'ac'         => 'check',  //固定值
    'appid'      => $appId,        //APPID的值
    'sdkversion' => '2.1.6',
    'sessionid'  => str_replace(' ','+', $sessionId),    //
    'time'       => time()
);

$data['sign'] = md5( http_build_query($data) . $key );

$response = post_request( $url, $data ); //验证登陆返回的数据
$result = json_decode( $response, true );

//var_dump($res); 如果成功的话返回值格式：{"userInfo":{"username":"yx598640","uid":"6596"},"code":1}
if($result['code'] == '1'){
    $uid = $result['userInfo']['uid']; // 用户 ID
    $username = $result['userInfo']['username']; //用户名

}


/**
 * @desc post request
 * @param string $url post 路径
 * @param array $post post 数据
 * @return string
 */
function post_request( $url, $post ) {
    $curl = curl_init();
    curl_setopt( $curl, CURLOPT_URL, $url );
    curl_setopt( $curl, CURLOPT_HEADER, 0 );
    curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
    curl_setopt( $curl, CURLOPT_POST, 1 );
    curl_setopt( $curl, CURLOPT_POSTFIELDS, $post );
    if(strpos("https")){
        curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, FALSE ); // https请求 不验证证书和hosts
        curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, FALSE );
    }
    
    $response = curl_exec( $curl );

    if(curl_errno($curl)) {
        curl_close( $curl );

        return false;
    }

    curl_close( $curl );

    return $response;
}

<?php
/**
 * User: yyjiasy
 * Version: 2.0.1
 * Date: 2017/03/06
 * Time: 10:09
 */

$payKey = "xxxx"; //对接参数 支付KEY
$appId = "123";   //对接参数 APPID的值
$data = $_GET;

$result = array(
	'amount'    => $data['amount'],  //金额 单位元
    'appid'     => $data['appid'],
    'charid'    => $data['charid'],    //角色ID
    'cporderid' => $data['cporderid'], //CP游戏商订单号
    'extinfo'   => $data['extinfo'],   //扩展信息 游戏发起支付请求时传递过来的callbackInfo
    'gold'      => $data['gold'],
    'orderid'   => $data['orderid'],   //支付平台的订单号
    'serverid'  => $data['serverid'],
    'time'      => $data['time'],
    'uid'       => $data['uid']        //用户的UID
);

$sign = $data['sign'];

$signed = md5( http_build_query( $result ) . $payKey );

if ( $sign == $signed ) {
    //在这里处理发货操作
    echo "SUCCESS";

} else {
    echo "ERROR";

}

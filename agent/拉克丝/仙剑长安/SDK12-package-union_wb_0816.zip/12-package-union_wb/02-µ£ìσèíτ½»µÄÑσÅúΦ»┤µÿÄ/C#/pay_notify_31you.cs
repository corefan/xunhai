﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

//
// 摘要:
//     定义一个用于以异步方式创建 System.Net.Http.HttpResponseMessage 的命令。
public interface IHttpActionResult
{
    //
    // 摘要:
    //     以异步方式创建 System.Net.Http.HttpResponseMessage。
    //
    // 参数:
    //   cancellationToken:
    //     要监视的取消请求标记。
    //
    // 返回结果:
    //     在完成时包含 System.Net.Http.HttpResponseMessage 的任务。
    Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken);
}

public class TextResult : IHttpActionResult
{
    string _value;
    HttpRequestMessage _request;
    Encoding _encode;

    public TextResult(string value, HttpRequestMessage request, Encoding encode)
    {
        _value = value;
        _request = request;
        _encode = encode;
    }
    public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
    {
        if (_encode != null)
        {
            byte[] buf = System.Text.Encoding.Default.GetBytes(_value);

            ByteArrayContent con = new ByteArrayContent(buf);
            var response = new HttpResponseMessage();
            response.RequestMessage = _request;
            response.Content = con;
            return Task.FromResult(response);
        }
        else
        {
            var response = new HttpResponseMessage()
            {
                Content = new StringContent(_value),
                RequestMessage = _request
            };
            return Task.FromResult(response);
        }
    }
}

class pay_notify_31you : ApiController
{
    static string Pay_Key = "支付key";

    private string Md5(string source)
    {
        MD5 md5 = new MD5CryptoServiceProvider();
        byte[] result = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(source));
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < result.Length; i++)
        {
            sb.Append(result[i].ToString("x2"));
        }

        return sb.ToString();
    }

    protected IHttpActionResult GetStringResult(string value, Encoding encode = null)
    {
        if (encode == null)
            encode = Encoding.UTF8;
        return new TextResult(value, Request, encode);
    }

    //签名成功处理函数
    protected string DoSdkNotify(string amount, string appid, string charid, string cporderid, string extinfo, string gold, string orderid, string serverid, string time, string uid, string sign)
    {
        string result = "SUCCESS";
        return result;
    }

    [HttpGet]
    public IHttpActionResult get_iapppay_success_notify(string amount, string appid, string charid, string cporderid, string extinfo, string gold, string orderid, string serverid, string time, string uid, string sign)
    {
        //校验签名是否正确
        string code = string.Format("amount={0}&appid={1}&charid={2}&cporderid={3}&extinfo={4}&gold={5}&orderid={6}&serverid={7}&time={8}&uid={9}{10}",
            HttpUtility.UrlEncode(amount), HttpUtility.UrlEncode(appid), HttpUtility.UrlEncode(charid), HttpUtility.UrlEncode(cporderid),
            HttpUtility.UrlEncode(extinfo), HttpUtility.UrlEncode(gold), HttpUtility.UrlEncode(orderid), HttpUtility.UrlEncode(serverid),
            time, HttpUtility.UrlEncode(uid), Pay_Key);

        string md5 = Md5(code);

        //签名失败
        if(md5 != sign)
        {
            return GetStringResult("ERROR");
        }

        //处理签名成功
        return GetStringResult(DoSdkNotify(amount, appid, charid, cporderid, extinfo, gold, orderid, serverid, time, uid, sign));
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;

public class login
{
    static string App_Id = "游戏id";
    static string Login_Key = "登陆key";
    static string Login_Url = "https://api.nkyouxi.com/sdkapi.php";
    
    private static string Md5(string source)
    {
        MD5 md5 = new MD5CryptoServiceProvider();
        byte[] result = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(source));
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < result.Length; i++)
        {
            sb.Append(result[i].ToString("x2"));
        }

        return sb.ToString();
    }

    private static string HttpPost(string Url, string postDataStr)
    {
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
        request.Method = "POST";
        request.ContentType = "application/x-www-form-urlencoded";
        request.ContentLength = postDataStr.Length;
        StreamWriter writer = new StreamWriter(request.GetRequestStream(), Encoding.UTF8);
        writer.Write(postDataStr);
        writer.Flush();
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        string encoding = response.ContentEncoding;
        if (encoding == null || encoding.Length < 1)
        {
            encoding = "UTF-8"; 
        }
        StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(encoding));
        string retString = reader.ReadToEnd();
        return retString;
    }

    private static string UrlEncode(string temp, Encoding encoding)
    {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < temp.Length; i++)
        {
            string t = temp[i].ToString();
            string k = HttpUtility.UrlEncode(t, encoding);
            if (t == k)
            {
                stringBuilder.Append(t);
            }
            else
            {
                stringBuilder.Append(k.ToUpper());
            }
        }
        return stringBuilder.ToString();
    }

    private static int ParseNow()
    {
        var span = DateTime.Now - new DateTime(1970, 1, 1, 8, 0, 0);
        return (int)(span.TotalMilliseconds / 1000);
    }

    /// <summary>
    /// 1.通过游戏服务器 取得用户信息
    /// </summary>
    /// <param name="sessionId">游戏端返回的sessionid[注:YYJUserUID 即sessionid]</param>
    /// <returns></returns>
    public static bool GetCxhyLogin(string sessionId)
    {
        try
        {
            int time = ParseNow();
            string param = string.Format("ac=check&appid={0}&sdkversion=2.1.6&sessionid={1}&time={2}", App_Id, UrlEncode(sessionId, Encoding.UTF8), time);
            string code = string.Format("ac=check&appid={0}&sdkversion=2.1.6&sessionid={1}&time={2}{3}", App_Id, UrlEncode(sessionId.Replace(" ", "+"), Encoding.UTF8), time, Login_Key);
            string sign = Md5(code);
            param += "&sign=" + sign;
            string url = Login_Url;
            string sResponseFromServer = HttpPost(url, param);
            //如果成功的话返回值格式：{"userInfo":{"username":"yx598640","uid":"6596"},"code":1}
            if (!string.IsNullOrEmpty(sResponseFromServer) && sResponseFromServer.IndexOf("\"code\":1") >= 0)
                return true;
        }
        catch
        {

        }

        return false;
    }
}


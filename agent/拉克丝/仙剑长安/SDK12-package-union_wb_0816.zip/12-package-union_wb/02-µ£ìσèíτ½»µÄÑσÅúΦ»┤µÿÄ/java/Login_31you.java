package org.web.controller;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Calendar;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;

public class Login_31you {
    static String App_Id = "游戏id";
    static String Login_Key = "登陆key";
    static String Login_Url = "https://api.nkyouxi.com/sdkapi.php";
	
	private static String getMD5(String str) {
	    try {
	        MessageDigest md = MessageDigest.getInstance("MD5");
	        md.update(str.getBytes());
	        return new BigInteger(1, md.digest()).toString(16);
	    } catch (Exception e) {

	    }
	    
	    return "";
	}
	
	protected static String GetEncode(String str)
	{
		try {
			return URLEncoder.encode(str,"utf-8");
		} catch (Exception e) {
		}
		return "";
	}
	
    private static int ParseNow()
    {
    	return (int) (Calendar.getInstance().getTimeInMillis() / 1000);
    }
    
    
    private static void trustAllHosts()
    {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager()
        {
            public java.security.cert.X509Certificate[] getAcceptedIssuers()
            {
                return new java.security.cert.X509Certificate[] {};
            }

            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException
            {
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException
            {
            }
        } };

        // Install the all-trusting trust manager
        try
        {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static String HttpPost(String URL, String param) {
    	
        byte[] postData = param.getBytes();
        InputStream instr = null;
        try {
            URL url = new URL(URL);
            trustAllHosts();
            HttpsURLConnection urlCon = (HttpsURLConnection) url.openConnection();
            urlCon.setDoOutput(true);
            urlCon.setDoInput(true);
            urlCon.setUseCaches(false);
            urlCon.setRequestProperty("content-Type", "application/x-www-form-urlencoded");
            urlCon.setRequestProperty("charset", "utf-8");
            urlCon.setRequestProperty("Content-length",
                    String.valueOf(postData.length));
            System.out.println(String.valueOf(postData.length));
            DataOutputStream printout = new DataOutputStream(
                    urlCon.getOutputStream());
            printout.write(postData);
            printout.flush();
            printout.close();
            instr = urlCon.getInputStream();
            byte[] bis = IOUtils.toByteArray(instr);
            String ResponseString = new String(bis, "UTF-8");
            if ((ResponseString == null) || ("".equals(ResponseString.trim()))) {
                System.out.println("返回空");
            }
            System.out.println("返回数据为:" + ResponseString);
            return ResponseString;

        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        } finally {
            try {
                instr.close();

            } catch (Exception ex) {
                return "0";
            }
        }
    }    

    /// <summary>
    /// 1.通过游戏服务器 取得用户信息
    /// </summary>
    /// <param name="sessionId">游戏端返回的sessionid[注:YYJUserUID 即sessionid]</param>
    /// <returns></returns>
    public static boolean GetCxhyLogin(String sessionId)
    {
        try
        {
            int time = ParseNow();
            String param = String.format("ac=check&appid=%s&sdkversion=2.1.6&sessionid=%s&time=%s", App_Id, GetEncode(sessionId), time);
            String code = String.format("ac=check&appid=%s&sdkversion=2.1.6&sessionid=%s&time=%s%s", App_Id, GetEncode(sessionId.replace(" ", "+")), time, Login_Key);
            String sign = getMD5(code);
            param += "&sign=" + sign;
            String url = Login_Url;
            String sResponseFromServer = HttpPost(url, param);
            //如果成功的话返回值格式：{"userInfo":{"username":"yx598640","uid":"6596"},"code":1}
            if (sResponseFromServer != null && sResponseFromServer.indexOf("\"code\":1") >= 0)
                return true;
        }
        catch(Exception e)
        {

        }

        return false;
    }
    
//	public static void main(String[] args)
//	{
//		boolean str = GetCxhyLogin("cdcc492773479cf04d7ee08852c719c9");
//	}
}

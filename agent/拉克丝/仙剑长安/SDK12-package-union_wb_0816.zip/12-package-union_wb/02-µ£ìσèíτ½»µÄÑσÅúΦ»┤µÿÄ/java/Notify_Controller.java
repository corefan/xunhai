package org.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicReference;

@Controller
@RequestMapping("/")
public class Notify_Controller {
	
	static String Pay_Key = "支付key";
	
	private static String getMD5(String str) {
	    try {
	        MessageDigest md = MessageDigest.getInstance("MD5");
	        md.update(str.getBytes());
	        return new BigInteger(1, md.digest()).toString(16);
	    } catch (Exception e) {

	    }
	    
	    return "";
	}
	
	protected String GetEncode(String str)
	{
		try {
			return URLEncoder.encode(str,"utf-8");
		} catch (Exception e) {
		}
		return "";
	}
	
    //签名成功处理函数
    protected String DoSdkNotify(String amount, String appid, String charid, String cporderid, String extinfo, String gold, String orderid, String serverid, String time, String uid, String sign)
    {
    	String result = "SUCCESS";
        return result;
    }
    
	@ResponseBody
	@RequestMapping(value = "31you_pay_notify", method = RequestMethod.GET)
	public String pay_notify(@RequestParam("amount") String amount,@RequestParam("appid") String appid,@RequestParam("charid") String charid, @RequestParam("cporderid") String cporderid
			, @RequestParam("extinfo") String extinfo, @RequestParam("gold") String gold, @RequestParam("orderid") String orderid, @RequestParam("serverid") String serverid
			, @RequestParam("time") String time, @RequestParam("uid") String uid, @RequestParam("sign") String sign) {

		String code = String.format("amount=%s&appid=%s&charid=%s&cporderid=%s&extinfo=%s&gold=%s&orderid=%s&serverid=%s&time=%s&uid=%s%s",
				GetEncode(amount), GetEncode(appid), GetEncode(charid), GetEncode(cporderid),
				GetEncode(extinfo), GetEncode(gold), GetEncode(orderid), GetEncode(serverid),
            time, GetEncode(uid), Pay_Key);

		String md5 = getMD5(code);

        //签名失败
        if(!md5.equals(sign))
        {
            return "ERROR";
        }

        //处理签名成功
        return DoSdkNotify(amount, appid, charid, cporderid, extinfo, gold, orderid, serverid, time, uid, sign);
	}
	
//	public static void main(String[] args)
//	{
//		WebController wc = new WebController();
//		String str = wc.pay_notify("0.01", "104", "107717", "1492522032811", "1492522032811", "0", "201704181327151090", "1", "1492493235", "21", "cdcc492773479cf04d7ee08852c719c9");
//	}
}

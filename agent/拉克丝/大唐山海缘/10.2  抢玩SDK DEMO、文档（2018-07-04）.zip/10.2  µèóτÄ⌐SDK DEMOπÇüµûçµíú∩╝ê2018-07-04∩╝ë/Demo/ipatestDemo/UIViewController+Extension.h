//
//  UIViewController+Extension.h
//  
//
//  Created by he on 17/3/28.
//  Copyright © 2017年 he. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Extension)
/**
 获取当前正在显示的ViewController
 
 @return UIViewController
 */
+ (UIViewController*) currentViewController;
@end

//
//  QWbutton.m
//  ipatestDemo
//
//  Created by 宁真 on 2016/12/22.
//  Copyright © 2016年 张高杰. All rights reserved.
//

#import "QWButton.h"

@interface QWbutton ()

@property (nonatomic, strong, nullable) UIColor *beginColor;

@property (nonatomic, strong, nullable) UIColor *endColor;

@end

@implementation QWbutton

+ (instancetype)btnWithBeginColor:(UIColor *)begin endColor:(UIColor *)end {
    QWbutton *btn = [self buttonWithType:UIButtonTypeCustom];
    btn.beginColor = begin;
    btn.endColor = end;
    return btn;
}

- (void)drawRect:(CGRect)rect {
    CGContextRef currenRef = UIGraphicsGetCurrentContext();
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGFloat location[2] = {0.0,1.0};
    CFArrayRef colors = CFArrayCreate(kCFAllocatorDefault, (const void*[]){_beginColor.CGColor,_endColor.CGColor}, 2, nil);
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, colors, location);
    CGPoint start = CGPointMake(self.frame.size.width * 0.5, 0);
    CGPoint end = CGPointMake(self.frame.size.width * 0.5, self.frame.size.height);
    UIGraphicsPushContext(currenRef);
    CGContextDrawLinearGradient(currenRef, gradient, start, end, 0);
    UIGraphicsPopContext();
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
    
}


@end

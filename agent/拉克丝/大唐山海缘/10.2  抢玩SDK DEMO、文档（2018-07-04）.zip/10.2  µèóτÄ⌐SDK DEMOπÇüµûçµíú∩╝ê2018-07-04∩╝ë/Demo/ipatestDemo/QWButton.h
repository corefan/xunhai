//
//  QWbutton.h
//  ipatestDemo
//
//  Created by 宁真 on 2016/12/22.
//  Copyright © 2016年 张高杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QWbutton : UIButton

+ (instancetype)btnWithBeginColor:(UIColor *)begin endColor:(UIColor *)end;

@end
